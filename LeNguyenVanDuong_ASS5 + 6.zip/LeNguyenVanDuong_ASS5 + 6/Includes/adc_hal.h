/*
 * adc_hal.h
 *
 *  Created on: Jan 8, 2024
 *      Author: Le Nguyen Van Duong
 */

#ifndef SOURCES_ADC_HAL_ADC_HAL_H_
#define SOURCES_ADC_HAL_ADC_HAL_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "MKL46Z4.h"
#include "sim_hal.h"
#include "port_hal.h"

/* Enumeration for ADC resolution modes */
typedef enum
{
	Adc8Resolution 	= 0u,	/* 8-bit ADC resolution */
	Adc12Resolution = 1u,	/* 12-bit ADC resolution */
	Adc10Resolution = 2u,	/* 10-bit ADC resolution */
	Adc16Resolution = 3u,	/* 16-bit ADC resolution */

}Resolution_Mode;
/* Enumeration for ADC clock divider modes */
typedef enum
{
	DividerBy1 = 0u,		/* Divide ADC clock by 1 */
	DividerBy2 = 1u,		/* Divide ADC clock by 2 */
	DividerBy4 = 2u,		/* Divide ADC clock by 4 */
	DividerBy8 = 3u,		/* Divide ADC clock by 8 */

}Divider_Mode;
/* Enumeration for ADC channel selection */
typedef enum
{
	Chn0       = 0U,		/* ADC Channel 0 */
	Chn1       = 1U,		/* ADC Channel 1 */
	Chn2 	   = 2U,		/* ADC Channel 2 */
	Chn3	   = 3U,		/* ADC Channel 3 */
	TempSensor = 26U,		/* Temperature sensor */
	Bandgap    = 27U,		/* Bandgap reference voltage */
	VREFSH     = 29U,		/* Voltage reference high */
	Disable    = 31U,		/* ADC channel disabled */

}Channel_Select;
/* Enumeration for ADC long sample time selection */
typedef enum
{
	Adc24Cycles = 0U,		/* 24 ADC clock cycles for long sample time */
	Adc16Cycles = 1U,		/* 16 ADC clock cycles for long sample time */
	Adc10Cycles = 2U,		/* 10 ADC clock cycles for long sample time */
	Adc6Cycles  = 3U,		/* 6 ADC clock cycles for long sample time */

}Long_Sample_Time_Select;
/* Enumeration for ADC trigger modes */
typedef enum
{
	SWTrigger = 0U,			/* Software trigger for ADC conversion */
	HWTrigger = 1U,			/* Hardware trigger for ADC conversion */

}Trigger_Mode;
/* Structure to hold ADC configuration parameters */
typedef struct
{
	Resolution_Mode Mode;					/* ADC resolution mode */
	Divider_Mode 	Div;					/* ADC clock divider mode */
	Channel_Select 	Channel;				/* ADC channel selection */
	bool 			Low_Power_Config;		/* Low power configuration */
	bool 			Sample_Time_Config;		/* Sample time configuration */
	Long_Sample_Time_Select Select;			/* Long sample time selection */
	bool 			High_Speed_Config;		/* High-speed configuration */
	bool 			DMAEnable;				/* DMA enable */
	bool 			continuousConvEnable; 	/* Continuous conversion enable */
	Trigger_Mode 	Trigger;				/* ADC trigger mode */

}Adc0ConverterConfig;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:		ADC0_HAL_Init
  * Description:	  	Initializes ADC0 based on the provided configuration.
  * @param ConfigPtr: 	Configuration structure for ADC0.
  * @return: None
  ************************************************************************************/
void ADC0_HAL_Init(Adc0ConverterConfig  ConfigPtr);

/*************************************************************************************
  * Function Name:		ADC0_HAL_ConfigConverter
  * Description:		Configures additional settings for ADC0
  * @param ConfigPtr: 	Configuration structure for ADC0.
  * @return None
  ************************************************************************************/
void ADC0_HAL_ConfigConverter(Adc0ConverterConfig ConfigPtr);

/*************************************************************************************
  * Function Name:		ADC0_HAL_Read
  * Description:		Reads the ADC conversion result from ADC0.
  * @param ConfigPtr: 	Configuration structure for ADC0.
  * @return uint32_t: 	ADC conversion result.
  ************************************************************************************/
uint32_t ADC0_HAL_Read(Adc0ConverterConfig ConfigPtr);

#endif /* SOURCES_ADC_HAL_ADC_HAL_H_ */
