/*
 * systick_timer_driver.h
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */
#ifndef SOURCES_SYSTICK_TIMER_DRIVER_SYSTICK_TIMER_DRIVER_H_
#define SOURCES_SYSTICK_TIMER_DRIVER_SYSTICK_TIMER_DRIVER_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "MKL46Z4.h"
#include "core_cm0plus.h"

/* Maximum number of timers in Timer_Group array */
#define MAX 4
/* Typedef for a function pointer to a function with no arguments and void return type */
typedef void( *func_ptr)(void);
/*  Structure for configuring Systick_Timer */
typedef struct
{
    uint32_t count; 	/* Counter value for the timer */
    func_ptr user_func; /* Pointer to the callback function */
}
Systick_Timer;
/* Array to store instances of Systick_Timer */
Systick_Timer Timer_Group[MAX];
/* Enum type for the state of the SysTick timer */
typedef enum
{
    SYSTICK_OK,
    SYSTICK_ERROR
}
Systick_State;

/************************************************************************************
 * Prototypes
 ************************************************************************************/
/*************************************************************************************
 * Function Name:		SYSTICK_DRV_Init
 * Description:			Initializes the SysTick timer.
 * @param  None
 * @param  None
 * @return None
 ************************************************************************************/
void SYSTICK_DRV_Init(void);

/*************************************************************************************
 * Function Name:		 SYSTICK_DRV_Start
 * Description:			 Starts the SysTick timer with a specified value.
 * @param  value		 The value to be loaded into the SysTick timer
 * @return Systick_State SYSTICK_OK if successful, SYSTICK_ERROR otherwise
 ************************************************************************************/
Systick_State SYSTICK_DRV_Start(uint32_t value);

/*************************************************************************************
 * Function Name:		SYSTICK_DRV_State
 * Description:			Returns the state of the SysTick timer.
 * @param  None
 * @return uint32_t:    The COUNTFLAG bit from the CTRL register
 ************************************************************************************/
uint32_t SYSTICK_DRV_State();

/*************************************************************************************
 * Function Name:		  SYSTICK_DRV_AddTimer
 * Description:			  Adds a timer object to the Timer_Group array.
 * @param  object:        Pointer to the Systick_Timer object to be added
 * @return Systick_State: SYSTICK_OK if successful, SYSTICK_ERROR otherwise
 ************************************************************************************/
Systick_State SYSTICK_DRV_AddTimer(Systick_Timer * object);

/*************************************************************************************
 * Function Name:		  SYSTICK_DRV_RemoveTimer
 * Description:			  Removes a timer from the Timer_Group array.
 * @param  index:         Index of the timer to be removed
 * @return Systick_State: SYSTICK_OK if successful, SYSTICK_ERROR otherwise
 ************************************************************************************/
Systick_State SYSTICK_DRV_RemoveTimer(uint8_t index);

#endif /* SOURCES_SYSTICK_TIMER_DRIVER_SYSTICK_TIMER_DRIVER_H_ */
