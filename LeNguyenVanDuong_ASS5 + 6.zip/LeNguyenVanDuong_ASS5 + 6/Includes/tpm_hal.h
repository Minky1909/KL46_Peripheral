/*
 * tpm_hal.h
 *
 *  Created on: Jan 9, 2024
 *      Author: Le Nguyen Van Duong
 */

#ifndef SOURCES_TPM_HAL_TPM_HAL_H_
#define SOURCES_TPM_HAL_TPM_HAL_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "MKL46Z4.h"
#include "sim_hal.h"
#include "port_hal.h"

/* Enumeration for TPM0 clock prescaler values */
typedef enum
{
	TpmDividedBy1 	= 0U,        	     /* TPM module clock prescaler, by 1 */
	TpmDividedBy2 	= 1U,         		 /* TPM module clock prescaler, by 2 */
	TpmDividedBy4 	= 2U,          		 /* TPM module clock prescaler, by 4 */
	TpmDividedBy8 	= 3U,          		 /* TPM module clock prescaler, by 8 */
	TpmDividedBy16 	= 4u,          		 /* TPM module clock prescaler, by 16 */
	TpmDividedBy32 	= 5U,          		 /* TPM module clock prescaler, by 32 */
	TpmDividedBy64 	= 6U,          		 /* TPM module clock prescaler, by 64 */
	TpmDividedBy128 = 7U,          		 /* TPM module clock prescaler, by 128 */

}Tpm0_Clock_Ps;
/* Enumeration for TPM0 clock mode values */
typedef enum
{
    TpmCounterDisable 			= 0U,    /* TPM clock mode, None CLK */
    TpmCounterSourceModuleClk 	= 1U,    /* TPM clock mode, Module CLK */
    TpmCounterExternalClk 		= 2U,    /* TPM clock mode, External input clock */

}Tpm0_Clock_Mode;
/* Enumeration for TPM0 channel values */
typedef enum
{
	Tpm_Chn0 = 0U,						 /* TPM0 Channel 0 */
	Tpm_Chn1 = 1U,						 /* TPM0 Channel 1 */
	Tpm_Chn2 = 2U,					     /* TPM0 Channel 2 */
	Tpm_Chn3 = 3U,						 /* TPM0 Channel 3 */
	Tpm_Chn4 = 4U,						 /* TPM0 Channel 4 */
	Tpm_Chn5 = 5U,						 /* TPM0 Channel 5 */

}Tpm0_Channel;
/* Enumeration for TPM0 PWM modes */
typedef enum
{
	TpmEdgeALignedPWM 	= 0U,			 /* Edge-aligned PWM mode for TPM0 */
	TpmCenterAlignedPWM = 1U,			 /* Center-aligned PWM mode for TPM0 */

}Tpm0_Pwm_Mode;
/* Structure to hold parameters for configuring TPM0 PWM */
typedef struct
{
	Tpm0_Clock_Ps 	prescaler;			 /* TPM0 clock prescaler value */
	Tpm0_Clock_Mode counter;			 /* TPM0 clock mode */
	Tpm0_Channel 	Channel;			 /* Selected TPM0 channel */
	Tpm0_Pwm_Mode 	Mode;			     /* Selected PWM mode */
	uint32_t 		FrequencyHZ;		 /* Desired PWM frequency Hz */

}Tpm0_Pwm_Param;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:	 	TPM0_HAL_Init
  * Description:	  	Initializes TPM0 for PWM based on the provided configuration.
  * @param ConfigPtr: 	Configuration structure for TPM0 PWM parameters.
  * @return None
  ************************************************************************************/
void TPM0_HAL_Init(Tpm0_Pwm_Param  ConfigPtr);

/*************************************************************************************
  * Function Name:		TPM0_HAL_PwmStart
  * Description:		Starts PWM operation on TPM0 and duty cycle value.
  * @param ConfigPtr: 	Configuration structure for TPM0 PWM parameters.
  * @param value: 		Duty cycle value
  * @return None
  ************************************************************************************/
void TPM0_HAL_PwmStart(Tpm0_Pwm_Param  ConfigPtr,uint16_t value);

/*************************************************************************************
  * Function Name:		TPM0_HAL_PwmStop
  * Description:		Stops PWM operation on TPM0 based on the provided configuration.
  * @param ConfigPtr: 	Configuration structure for TPM0 PWM parameters.
  * @return None
  ************************************************************************************/
void TPM0_HAL_PwmStop(Tpm0_Pwm_Param  ConfigPtr);

#endif /* SOURCES_TPM_HAL_TPM_HAL_H_ */
