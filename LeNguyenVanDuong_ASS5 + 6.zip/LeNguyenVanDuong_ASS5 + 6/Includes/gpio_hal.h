/*
 * gpio_hal.h
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */

#ifndef _GPIO_HAL_H_
#define _GPIO_HAL_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "MKL46Z4.h"

/* Type-define enum for specifying pin direction (input or output) */
typedef enum
{
    GpioDigitalInput  = 0U, /* Set current pin as digital input */
    GpioDigitalOutput = 1U  /* Set current pin as digital output */

}Pin_Direct;

/* Type-define enum for specifying digital logic level (low or high) */
typedef enum
{
    GpioDigitalLow    = 0U, /* Set current pin as digital input */
    GpioDigitalHigh   = 1U  /* Set current pin as digital output */

}Pin_Logic;

/* Type-define enum for specifying digital logic level (low or high) */
typedef enum
{
    HAL_GPIOA         = 1U, /* HAL_GPIO identifier for GPIOA */
    HAL_GPIOB         = 2U, /* HAL_GPIO identifier for GPIOB */
    HAL_GPIOC         = 3U, /* HAL_GPIO identifier for GPIOC */
    HAL_GPIOD         = 4U, /* HAL_GPIO identifier for GPIOD */
    HAL_GPIOE         = 5U, /* HAL_GPIO identifier for GPIOE */

}Hal_Gpio;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:		GPIO_HAL_Output
  * Description:		Set the logic level of a specific GPIO pin configured as an output
  * @param Gpio: 		Identifier for the HAL_GPIO
  * @param Pin: 		Pin number within the GPIO port
  * @param Logic:       Desired logic level for the pin (low or high)
  * @return None
  ************************************************************************************/
void GPIO_HAL_Output(Hal_Gpio gpio_name,uint8_t Pin,Pin_Logic Logic );

/*************************************************************************************
  * Function Name:		GPIO_HAL_Clear_Output
  * Description:		Clear the output of a specific GPIO pin
  * @param Gpio: 		Identifier for the HAL_GPIO
  * @param Pin: 		Pin number within the GPIO port
  * @return None
  ************************************************************************************/
void GPIO_HAL_Clear_Output(Hal_Gpio gpio_name,uint8_t Pin);

/*************************************************************************************
  * Function Name:		GPIO_HAL_Set_Output
  * Description:		Set the output of a specific GPIO pin
  * @param Gpio: 		Identifier for the HAL_GPIO
  * @param Pin: 		Pin number within the GPIO port
  * @return None
  ************************************************************************************/
void GPIO_HAL_Set_Output(Hal_Gpio Gpio, uint8_t Pin);

/*************************************************************************************
  * Function Name:		GPIO_HAL_Toggle_Output
  * Description:		Toggles the logic level of a specific GPIO pin configured as an output.
  * @param Gpio: 		Identifier for the HAL_GPIO
  * @param Pin: 		Pin number within the GPIO port
  * @return None
  ************************************************************************************/
void GPIO_HAL_Toggle_Output(Hal_Gpio gpio_name,uint8_t Pin);

/*************************************************************************************
  * Function Name:	    GPIO_HAL_DataDirection
  * Description:		Configures the data direction (input or output) for a specific GPIO pin
  * @param Gpio: 		Identifier for the HAL_GPIO
  * @param Pin: 		Pin number within the GPIO port
  * @param Direct:      Desired data direction for the pin (input or output).
  * @return None
  ************************************************************************************/
void GPIO_HAL_DataDirection(Hal_Gpio gpio_name,uint8_t Pin,Pin_Direct Direct);

/*************************************************************************************
  * Function Name:		GPIO_HAL_Set_Input
  * Description:		Configures a specific GPIO pin as an input and reads its logic level.
  * @param Gpio: 		Identifier for the HAL_GPIO
  * @param Pin: 		Pin number within the GPIO port
  * @return uint32_t:   Logic level of the specified input pin (0 or 1)
  ************************************************************************************/
uint32_t GPIO_HAL_Set_Input(Hal_Gpio gpio_name,uint8_t Pin);


#endif /* SOURCES_GPIO_HAL_GPIO_HAL_H_ */
