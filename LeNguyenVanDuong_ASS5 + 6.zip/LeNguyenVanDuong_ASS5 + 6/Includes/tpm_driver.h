/*
 * tpm_driver.h
 *
 *  Created on: Jan 9, 2024
 *      Author: Le Nguyen Van Duong
 */

#ifndef SOURCES_PWM_DRIVER_PWM_DRIVER_H_
#define SOURCES_PWM_DRIVER_PWM_DRIVER_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "tpm_hal.h"
#include "gpio_driver.h"

/* Structure for TPM0 channels, specifying GPIO and PWM parameters.*/
typedef struct
{
    gpio_name 		PortName;	/* GPIO port name for TPM0 pin */
    uint32_t 		PinName;	/* GPIO pin number for TPM0 pin */
    Port_Mux 		Mux;		/* GPIO pin multiplexing mode for TPM0 pin */
    Tpm0_Pwm_Param  ConfigPtr;	/* TPM0 PWM configuration parameters */

}Tpm0_config;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:	TPM0_DRV_Init
  * Description:	Initializes multiple TPM0 channels based on the provided array of configurations.
  * @param Config: 	Pointer to an array of Tpm0_config structures containing TPM0 configurations.
  * @return None
  ************************************************************************************/
void TPM0_DRV_Init(Tpm0_config * Config);

/*************************************************************************************
  * Function Name:	TPM0_DRV_Config
  * Description:	Configures a single TPM0 channel based on the provided configuration.
  * @param Config: 	Pointer to the Tpm0_config structure containing TPM0 channel configuration.
  * @return None
  ************************************************************************************/
static void TPM0_DRV_Config(Tpm0_config * Config);

/*************************************************************************************
  * Function Name:	TPM0_DRV_PwmStart
  * Description:	Starts PWM operation on a TPM0 channel and duty cycle value.
  * @param Config: 	Pointer to the Tpm0_config structure containing TPM0 channel configuration.
  * @param value: 	Duty cycle value
  * @return None
  ************************************************************************************/
void TPM0_DRV_PwmStart(Tpm0_config * Config,uint16_t value);

/*************************************************************************************
  * Function Name:	TPM0_DRV_PwmStop
  * Description:	Stops PWM operation on a TPM0 channel based on the provided configuration.
  * @param Config: 	Pointer to the Tpm0_config structure containing TPM0 channel configuration.
  * @return None
  ************************************************************************************/
void TPM0_DRV_PwmStop(Tpm0_config * Config);

#endif /* SOURCES_PWM_DRIVER_PWM_DRIVER_H_ */
