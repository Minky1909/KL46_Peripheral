/*
 * tpm_driver.c
 *
 *  Created on: Jan 9, 2024
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "tpm_driver.h"

/************************************************************************************
 * Function
 ************************************************************************************/
void TPM0_DRV_Init(Tpm0_config * Config)
{

    while (Config -> PinName != GPIO_PINS_OUT_OF_RANGE)
    {
        TPM0_DRV_Config(Config++);
    }

}

static void TPM0_DRV_Config(Tpm0_config * Config)
{
	/* Enable the clock for the specified GPIO port */
    SIM_EnablePortClock(Config -> PortName);
    /* Enable the clock for TPM0 module */
    SIM_EnableClock_TMP0(Config -> PortName);
    /* Set the pin multiplexing mode for the TPM0 pin */
    PORT_HAL_SetMuxMode(Config -> PortName, Config -> PinName, Config -> Mux);
    /* Initialize TPM0 based on the provided configuration */
    TPM0_HAL_Init(Config -> ConfigPtr);
}

void TPM0_DRV_PwmStart(Tpm0_config * Config, uint16_t value)
{
	/* Delegate the PWM start operation to TPM0_HAL_PwmStart function */
    TPM0_HAL_PwmStart(Config -> ConfigPtr, value);

}

void TPM0_DRV_PwmStop(Tpm0_config * Config)
{
	/* Delegate the PWM stop operation to TPM0_HAL_PwmStop function */
    TPM0_HAL_PwmStop(Config -> ConfigPtr);

}

/* End of file */
