/*
 * tpm_hal.c
 *
 *  Created on: Jan 9, 2024
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "tpm_hal.h"

/************************************************************************************
 * Function
 ************************************************************************************/
void TPM0_HAL_Init(Tpm0_Pwm_Param ConfigPtr)
{
	/* Set the prescaler and start TPM0 counter */
    TPM0_SC = TPM_SC_PS(ConfigPtr.prescaler);
    TPM0_SC |= TPM_SC_CMOD(ConfigPtr.counter);
    /* Configure PWM aligned based on the specified mode */
    switch (ConfigPtr.Mode)
    {
    case TpmEdgeALignedPWM:
        TPM_CnSC_REG(TPM0, ConfigPtr.Channel) |= TPM_CnSC_MSB_MASK | TPM_CnSC_ELSB_MASK;
        break;
    case TpmCenterAlignedPWM:
        TPM_CnSC_REG(TPM0, ConfigPtr.Channel) |= TPM_CnSC_MSA_MASK | TPM_CnSC_ELSA_MASK;
        break;
    default:
        break;
    }
    /* Set the initial value for the PWM channel */
    TPM_CnV_REG(TPM0, ConfigPtr.Channel) = TPM_CnV_VAL_SHIFT;

}

void TPM0_HAL_PwmStart(Tpm0_Pwm_Param ConfigPtr, uint16_t value)
{
    uint32_t freq;
    uint16_t uMod, uCnv;
    /* Get the TPM clock frequency source */
    freq = SIM -> SOPT2 | SIM_SOPT2_TPMSRC(1);;
    /* Calculate MOD value for desired PWM frequency */
    uMod = (freq / ConfigPtr.FrequencyHZ) - 1;
    TPM0_MOD = uMod;
    /* Reset the TPM counter */
    TPM_CNT_REG(TPM0) = TPM_CNT_COUNT(0);
    /* Calculate CnV value based on the duty cycle */
    uCnv = (value * TPM0_MOD) / 100;
    /* Update CnV value for PWM channel */
    TPM_CnV_REG(TPM0, Tpm_Chn2) = TPM_CnV_VAL(uCnv);
    TPM_CnV_REG(TPM0, Tpm_Chn5) = TPM0_MOD - TPM_CnV_VAL(uCnv);
}

void TPM0_HAL_PwmStop(Tpm0_Pwm_Param ConfigPtr)
{
	/* Disable TPM0 counter */
    TPM0_SC |= TPM_SC_CMOD(TpmCounterDisable);

}

/* End of file */
