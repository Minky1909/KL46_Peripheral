/*
 * adc_hal.c
 *
 *  Created on: Jan 8, 2024
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "adc_hal.h"

/************************************************************************************
 * Function
 ************************************************************************************/
void ADC0_HAL_Init(Adc0ConverterConfig ConfigPtr)
{
	/*  Set the clock source for the ADC0 */
    ADC0_CFG1 = ADC_CFG1_ADICLK_SHIFT;
    /* Configure ADC0 mode and clock division */
    ADC0_CFG1 |= ADC_CFG1_MODE(ConfigPtr.Mode);
    ADC0_CFG1 |= ADC_CFG1_ADIV(ConfigPtr.Div);
    /* Set different mode to single-ended */
    ADC0_SC1(0) &= ~ADC_SC1_DIFF_MASK;

}

uint32_t ADC0_HAL_Read(Adc0ConverterConfig ConfigPtr)
{
	/* Clear the ADC channel selection */
    ADC0_SC1(0) &= ~ADC_SC1_ADCH_MASK;
    /*    Set the ADC channel for the conversion */
    ADC0_SC1(0) |= ADC_SC1_ADCH(ConfigPtr.Channel);
    /* Wait until the conversion is complete */
    while (!(ADC0_SC1(0) & ADC_SC1_COCO_MASK));
    /*    Return the ADC conversion result */
    return ADC0_R(0);

}

void ADC0_HAL_ConfigConverter(Adc0ConverterConfig ConfigPtr)
{
	/* Check and set low power configuration */
    if (ConfigPtr.Low_Power_Config == true)
    {
        ADC0_CFG1 |= ADC_CFG1_ADLPC_MASK;
    }
    /* Check and set sample time configuration */
    if (ConfigPtr.Sample_Time_Config == true)
    {
        ADC0_CFG1 |= ADC_CFG1_ADLSMP_MASK;
        ADC0_CFG2 |= ADC_CFG2_ADLSTS(ConfigPtr.Select);
    }
    /* Check and set high-speed configuration */
    if (ConfigPtr.High_Speed_Config == true)
    {
        ADC0_CFG2 |= ADC_CFG2_ADHSC_MASK;
    }
    /* Check and enable DMA */
    if (ConfigPtr.DMAEnable = true)
    {
        ADC0_SC2 |= ADC_SC2_DMAEN_MASK;
    }
    /* Check and enable continuous conversion */
    if (ConfigPtr.continuousConvEnable == true)
    {
        ADC0_SC3 |= ADC_SC3_ADCO_MASK;
    }
    /* Check the trigger type and configure according */
    if (ConfigPtr.Trigger == SWTrigger)
    {
        ADC0_SC2 &= ~ADC_SC2_ADTRG_MASK;
    }
    else
    {
        ADC0_SC2 |= ADC_SC2_ADTRG_MASK;
    }

}

/* End of file */
