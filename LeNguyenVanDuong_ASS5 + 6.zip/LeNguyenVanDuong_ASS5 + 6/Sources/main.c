/*
 * main.c
 *
 *  Created on: Jan 8, 2024
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "gpio_driver.h"
#include "adc_driver.h"
#include "tpm_driver.h"
/************************************************************************************
 * Definitions
 ************************************************************************************/
#define TPM0_PORT_D		(GPIO_D) /* TPM0 at PORT D */
#define TPM0_PIN_CHN5	(5) 	 /* TPM0 at Pin 5 */

#define TPM0_PORT_E		(GPIO_E) /* TPM0 at PORT E */
#define TPM0_PIN_CHN2	(29) 	 /* TPM0 at Pin 29 */

#define ADC0_PORT		(GPIO_E) /* ADC0 at PORT C */
#define ADC0_PIN		(22) 	 /* ADC0 at Pin 3 */

/************************************************************************************
 * Static Variable
 ************************************************************************************/
static Adc0_config Adc_config[1]; /* Static array for ADC configuration */
static Tpm0_config Tpm_config[3]; /* Static array for TPM0 configuration */

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:	Adc0_Config
  * Description: 	Configure ADC0 parameters for a single channel.
  * @param  None
  * @return None
  ************************************************************************************/
static void Adc0_Config(void);

/*************************************************************************************
  * Function Name:	Tpm0_Config
  * Description:	Configure TPM0 parameters for multiple channels.
  * @param  None
  * @return None
  ************************************************************************************/
static void Tpm0_Config(void);

/************************************************************************************
 * Function
 ************************************************************************************/
static void Adc0_Config(void)
{
	/* ADC0 Channel 3 Configuration */
	Adc_config[0].PortName 							   = ADC0_PORT;
	Adc_config[0].PinName 							   = ADC0_PIN;
	Adc_config[0].ConverterConfig.Mode 				   = Adc16Resolution;
	Adc_config[0].ConverterConfig.Div 				   = DividerBy4;
	Adc_config[0].ConverterConfig.Channel 			   = Chn3;
	Adc_config[0].ConverterConfig.Low_Power_Config     = true;
	Adc_config[0].ConverterConfig.High_Speed_Config    = false;
	Adc_config[0].ConverterConfig.Sample_Time_Config   = true;
	Adc_config[0].ConverterConfig.Select 			   = Adc16Cycles;
	Adc_config[0].ConverterConfig.DMAEnable 		   = false;
	Adc_config[0].ConverterConfig.continuousConvEnable = true;
	Adc_config[0].ConverterConfig.Trigger 			   = SWTrigger;

}

static void Tpm0_Config(void)
{
	/* TPM0 Channel 5 Configuration */
	Tpm_config[0].PortName 				= TPM0_PORT_D;
	Tpm_config[0].PinName  				= TPM0_PIN_CHN5;
	Tpm_config[0].Mux	   				= PortMuxAlt4;
	Tpm_config[0].ConfigPtr.Channel  	= Tpm_Chn5;
	Tpm_config[0].ConfigPtr.prescaler 	= TpmDividedBy1;
	Tpm_config[0].ConfigPtr.counter 	= TpmCounterSourceModuleClk;
	Tpm_config[0].ConfigPtr.Mode 		= TpmEdgeALignedPWM;
	Tpm_config[0].ConfigPtr.FrequencyHZ = 16400;
	/* TPM0 Channel 2 Configuration */
	Tpm_config[1].PortName 				= TPM0_PORT_E;
	Tpm_config[1].PinName  				= TPM0_PIN_CHN2;
	Tpm_config[1].Mux	   				= PortMuxAlt3;
	Tpm_config[1].ConfigPtr.Channel  	= Tpm_Chn2;
	Tpm_config[1].ConfigPtr.prescaler 	= TpmDividedBy1;
	Tpm_config[1].ConfigPtr.counter 	= TpmCounterSourceModuleClk;
	Tpm_config[1].ConfigPtr.Mode 		= TpmEdgeALignedPWM;
	/* Mark the end of the configuration array */
	Tpm_config[2].PinName 				= GPIO_PINS_OUT_OF_RANGE;

}

/*************************************************************************************
 * Function Name:          main
 * Description:            Main function
 ************************************************************************************/
int main(void)
{

    Adc0_Config();
    ADC0_DRV_Init(Adc_config);

    Tpm0_Config();
    TPM0_DRV_Init(Tpm_config);

    uint16_t adc_val;

    /*  Main program loop */
    while (1)
    {
    	/* Read value from ADC */
        adc_val = (ADC0_DRV_Read(Adc_config) * 100 / 65535);
        /* Start PWM on TPM0 */
        TPM0_DRV_PwmStart(Tpm_config, adc_val);

    }
    return 0;
}

/* End of file */
