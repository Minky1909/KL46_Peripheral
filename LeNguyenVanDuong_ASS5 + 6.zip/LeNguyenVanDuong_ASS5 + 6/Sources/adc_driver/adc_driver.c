/*
 * adc_driver.c
 *
 *  Created on: Jan 8, 2024
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "adc_driver.h"

/************************************************************************************
 * Function
 ************************************************************************************/

ADC_DRV_State ADC0_DRV_Init(Adc0_config * adc0_config)
{
    ADC_DRV_State Status;
    /* Check the specified port is within valid GPIO range (GPIO_B to GPIO_E) */
    if (adc0_config -> PortName >= GPIO_B && adc0_config -> PortName <= GPIO_E)
    {
    	/* Enable clock for the specified GPIO port */
        SIM_EnablePortClock(adc0_config -> PortName);
        /* Configure the pin multiplexing mode for the ADC pin */
        PORT_HAL_SetMuxMode(adc0_config -> PortName, adc0_config -> PinName, PortPinDisable);
        /* Enable clock for ADC0 */
        SIM_EnableClock_ADC0(adc0_config -> PortName);
        /* Initialize ADC0 hardware */
        ADC0_HAL_Init(adc0_config -> ConverterConfig);
        /* Initialize ADC0 hardware */
        ADC0_HAL_ConfigConverter(adc0_config -> ConverterConfig);
        /* Set status to indicate successful initialization */
        Status = ADC_DRV_OK;
    }
    else
    {
    	/* Set status to indicate an error due to invalid GPIO port */
        Status = ADC_DRV_ERROR;
    }

    return Status;
}

uint32_t ADC0_DRV_Read(Adc0_config * adc0_config)
{
	/* Delegate the ADC reading operation to the ADC0_HAL_Read function */
    return ADC0_HAL_Read(adc0_config -> ConverterConfig);

}

/* End of file */
