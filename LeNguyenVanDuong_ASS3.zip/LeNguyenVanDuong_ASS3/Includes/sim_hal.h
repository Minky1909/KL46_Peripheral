/*
 * sim_hal.h
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */

#ifndef _SIM_HAL_H_
#define _SIM_HAL_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "MKL46Z4.h"

/* Type-define enum Sim Port name */
typedef enum sim_port
{
    SIM_PORTA    = 1U,  /* Identifier for Sim Port A */
    SIM_PORTB    = 2U,  /* Identifier for Sim Port B */
    SIM_PORTC    = 3U,  /* Identifier for Sim Port C */
    SIM_PORTD    = 4U,  /* Identifier for Sim Port D */
    SIM_PORTE    = 5U,  /* Identifier for Sim Port E */

}sim_port;

/* Type-define enum check status sim_state */
typedef enum
{
	SIM_OK		 = 0u,  /* Status success */
	SIM_ERROR 	 = 1U,  /* Status error */

}sim_state;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:		SIM_EnablePortClock
  * Description:		Enables the clock gate.
  * @param  Port:       Identifier for the SIM_PORT
  * @return Status:     The status of the clock gate operation.
  ************************************************************************************/
sim_state SIM_EnablePortClock(sim_port Port);

#endif /* SOURCES_GPIO_HAL_SIM_HAL_H_ */
