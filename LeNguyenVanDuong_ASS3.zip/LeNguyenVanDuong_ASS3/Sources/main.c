/*
 * main.c
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include  "gpio_driver.h"

/************************************************************************************
 * Definitions
 ************************************************************************************/
#define GREEN_LED_PORT	(GPIO_D) 	/* Green LED at PORT D */
#define GREEN_LED_PIN	(5) 		/* Green LED at Pin 5 */
#define RED_LED_PORT	(GPIO_E) 	/* Red LED at PORT E */
#define RED_LED_PIN		(29) 		/* Red LED at Pin 29 */

#define SW1_PORT		(GPIO_C) 	/* Switch 1 at PORT C */
#define SW1_PIN			(3) 		/* Switch 1 at Pin 3 */
#define SW3_PORT		(GPIO_C) 	/* Switch 1 at PORT C */
#define SW3_PIN			(12) 		/* Switch 1 at Pin 12 */


#define GPIO_SW_HANDLER PORTC_PORTD_IRQHandler	/* Handler for extension port C */

/************************************************************************************
 * Static Variable
 ************************************************************************************/
static Gpio_Input_Pin_Config 	inputpin[5];	/* Array of configurations for input pins */
static Gpio_Output_Pin_Config 	Outputpin[5];	/* Array of configurations for output pins */

static volatile uint8_t isButtonPress = 0;		/* Variable to indicate whether a button is pressed */

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:      delayMs
  * Description:        Set the delay times
  * @param  time
  * @return None
  ************************************************************************************/
static void delayMs(uint32_t time);

/*************************************************************************************
  * Function Name:      Input_Config
  * Description:        Configures input pins.
  * @param  None
  * @return None
  ************************************************************************************/
static void Input_Config(void);

/*************************************************************************************
  * Function Name:      Output_Config
  * Description:		Configures output pins
  * @param  None
  * @return None
  ************************************************************************************/
static void Output_Config(void);

/************************************************************************************
 * Function
 ************************************************************************************/
static void delayMs(uint32_t time)
{
    int i = 0;
    int j = 0;

    for (i = 0; i < time; i++)
    {
        for (j = 0; j < 7000; j++)
        {}
    }
}

static void Input_Config(void)
{

    inputpin[0].PortName 					= SW1_PORT;
    inputpin[0].PinName 					= SW1_PIN;
    inputpin[0].Config.PullEnable 			= true;
    inputpin[0].Config.PullSelect	 		= PortPullUp;
    inputpin[0].Config.PassiveFilterEnable	= false;
    inputpin[0].Config.Interrupt_Config		= PortIntFallingEdge;

    inputpin[1].PortName 					= SW3_PORT;
    inputpin[1].PinName						= SW3_PIN;
    inputpin[1].Config.PullEnable			= true;
    inputpin[1].Config.PullSelect			= PortPullUp;
    inputpin[1].Config.PassiveFilterEnable	= false;
    inputpin[1].Config.Interrupt_Config		= PortIntFallingEdge;
    inputpin[1].Priority					= 1;

    inputpin[2].PinName 					= GPIO_PINS_OUT_OF_RANGE;

}

static void Output_Config(void)
{
    Outputpin[0].PortName 					= RED_LED_PORT;
    Outputpin[0].PinName 					= RED_LED_PIN;
    Outputpin[0].Config.Slew_Rate 			= PortFastSlew;
    Outputpin[0].Config.DriveStregth 		= PortHighDriveStrength;
    Outputpin[0].Config.OutputLogic 		= GpioDigitalHigh;

    Outputpin[1].PortName 					= GREEN_LED_PORT;
    Outputpin[1].PinName 					= GREEN_LED_PIN;
    Outputpin[1].Config.Slew_Rate 			= PortFastSlew;
    Outputpin[1].Config.DriveStregth 		= PortHighDriveStrength;
    Outputpin[1].Config.OutputLogic 		= GpioDigitalHigh;

    Outputpin[2].PinName 					= GPIO_PINS_OUT_OF_RANGE;

}

/*************************************************************************************
  * Function Name:          main
  * Description:            Main function
  ************************************************************************************/
int main(void)
{
    Input_Config();
    Output_Config();

    GPIO_DRV_Init(inputpin, Outputpin);
    GPIO_DRV_ClearOutput( & Outputpin[0]);
    GPIO_DRV_ClearOutput( & Outputpin[1]);
    /*  Main program loop */
    while (1)
    {
    	/* Check if the button is pressed */
        if (isButtonPress == 1)
        {
        	/* Toggle the state of the output pin */
            GPIO_DRV_TogglePinOutput( & Outputpin[0]);
            delayMs(50);

        }
        if (isButtonPress == 2)
        {
            GPIO_DRV_TogglePinOutput( & Outputpin[1]);
            delayMs(50);

        }

    }
    return 0;
}

void GPIO_SW_HANDLER(void)
{
    isButtonPress = 0;

    if (GPIO_DRV_InterruptFlag( & inputpin[0]) == 1)
    {

        isButtonPress = 1;

    }
    else if (GPIO_DRV_InterruptFlag( & inputpin[1]) == 1)
    {

        isButtonPress = 2;
    }
    else
    {
    	/* Do nothing */
    }
}
