/*
 * port_hal.c
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "port_hal.h"

/************************************************************************************
 * Static Variable
 ************************************************************************************/
/* Array mapping Hal_Port enum to corresponding NVIC interrupt */
static IRQn_Type IRQn[] = {PORTC_PORTD_IRQn,PORTA_IRQn};

/************************************************************************************
 * Static Function
 ************************************************************************************/
static PORT_Type * CheckPort(Hal_Port Port);

/*************************************************************************************
  * Function Name:		CheckPort
  * Description:		Corresponding PORT_Type pointer for a given HAL_PORT identifier.
  * @param  Port:       Identifier for the SIM_PORT
  * @return PORT_Type*: Pointer to the corresponding PORT_Type structure.
  ************************************************************************************/
static PORT_Type * CheckPort(Hal_Port Port)
{
    PORT_Type * Type;

    /* Array of PORT_Type pointers */
    PORT_Type * Port_Val[] = PORT_BASE_PTRS;

    int index = 0;

    if (Port >= HAL_PORTA && Port <= HAL_PORTE)
    {
        /* Calculate the index corresponding to the specified HAL_PORT */
        index = Port - HAL_PORTA;

        /* Get the PORT_Type pointer from the array */
        Type = Port_Val[index];
    }
    else
    {
        /* Do nothing */
    }
    return Type;
}

/************************************************************************************
 * Function
 ************************************************************************************/
void PORT_HAL_SetMuxMode(Hal_Port Port, uint8_t Pin, Port_Mux Muxing)
{

    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Clear the current muxing setting for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) &= ~PORT_PCR_MUX_MASK;
    /* Set the new muxing mode for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_MUX(Muxing);

}

void PORT_HAL_SetPullMode(Hal_Port Port, uint8_t Pin, Port_Pull Config)
{
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Set pull-up or pull-down configuration for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_PE_MASK | PORT_PCR_PS(Config);

}

Port_State PORT_HAL_SetInterruptsMode(Hal_Port Port, uint8_t Pin, Port_Interrupt_Config Config, uint8_t Priority)
{
    Port_State Status = HAL_PORT_OK;
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Enable NVIC interrupts based on the specified HAL_PORT */
    if ((Port == HAL_PORTC) || (Port == HAL_PORTD))
    {
        NVIC_EnableIRQ(IRQn[0]);
        NVIC_SetPriority(IRQn[0], Priority);
    }
    else if (Port == HAL_PORTA)
    {
        NVIC_EnableIRQ(IRQn[1]);
        NVIC_SetPriority(IRQn[1], Priority);
    }
    else
    {
        /* Invalid HAL_PORT, set status to error */
        Status = HAL_PORT_ERROR;
    }
    /* Clear the interrupt configure previous */
    PORT_PCR_REG(Port_Name, Pin) &= ~PORT_PCR_IRQC_MASK;
    /* Configure the interrupt */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_IRQC(Config);

    return Status;
}

uint32_t PORT_HAL_InterruptStatusFlag(Hal_Port Port, uint8_t Pin)
{
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Retrieve and return the status flag for the specified pin */
    return (PORT_ISFR_REG(Port_Name) >> Pin);

}

void PORT_HAL_ClearInterrupts(Hal_Port Port, uint8_t Pin)
{
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Set the interrupt status flag for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_ISF_MASK;
}

void PORT_HAL_SetSlewRateMode(Hal_Port Port, uint8_t Pin, Port_Slew_Rate Config)
{
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Set the slew rate configuration for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_SRE(Config);

}

void PORT_HAL_SetDriveStrengthMode(Hal_Port Port, uint8_t Pin, Port_Drive_Strength Config)
{
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Set the drive strength configuration for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_DSE(Config);
}

void PORT_HAL_PassiveFilter(Hal_Port Port, uint8_t Pin, Port_Passive_Filter Config)
{
    /* Get the PORT_Type pointer for the specified HAL_PORT */
    PORT_Type * Port_Name = CheckPort(Port);
    /* Set the passive filter configuration for the specified pin */
    PORT_PCR_REG(Port_Name, Pin) |= PORT_PCR_DSE(Config);
}

bool PORT_HAL_SetIntPending(Hal_Port Port)
{
	/* Check if the port is HAL_PORTC or HAL_PORTD */
    if ((Port == HAL_PORTC) || (Port == HAL_PORTD))
    {
    	/* Set interrupt pending for IRQn[0] interrupt */
        NVIC_SetPendingIRQ(IRQn[0]);
    }
    else if (Port == HAL_PORTA)
    {
    	/* Set interrupt pending for IRQn[1] interrupt */
        NVIC_SetPendingIRQ(IRQn[1]);
    }
    else
    {
    	/* Return false if the port is not recognized */
    	return false;
    }

}

void PORT_HAL_ClearIntPending(Hal_Port Port)
{
	/* Check if the port is HAL_PORTC or HAL_PORTD */
    if ((Port == HAL_PORTC) || (Port == HAL_PORTD))
    {
    	/* Clear interrupt pending for IRQn[0] interrupt */
        NVIC_ClearPendingIRQ(IRQn[0]);
    }
    else if (Port == HAL_PORTA)
    {
    	/* Clear interrupt pending for IRQn[1] interrupt */
        NVIC_ClearPendingIRQ(IRQn[1]);
    }
}

/* End of file */
