/*
 * gpio_driver.c
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "gpio_driver.h"

/************************************************************************************
 * Function
 ************************************************************************************/
void GPIO_DRV_Init(Gpio_Input_Pin_Config * InputPins, Gpio_Output_Pin_Config * OutputPins)
{
    /* Initialize GPIO input pins */
    if (InputPins)
    {
        while (InputPins -> PinName != GPIO_PINS_OUT_OF_RANGE)
        {
            GPIO_DRV_InputPinInit(InputPins++);
        }

    }
    /* Initialize GPIO output pins */
    if (OutputPins)
    {
        while (OutputPins -> PinName != GPIO_PINS_OUT_OF_RANGE)
        {
            GPIO_DRV_OutputPinInit(OutputPins++);
        }
    }
}

void GPIO_DRV_InputPinInit(Gpio_Input_Pin_Config * inputPin)
{
    /* Enable clock for the corresponding GPIO port */
    SIM_EnablePortClock(inputPin -> PortName);
    /* Set pin mux mode to GPIO */
    PORT_HAL_SetMuxMode(inputPin -> PortName, inputPin -> PinName, PortMuxGpio);
    /* Configure pin data direction as input */
    GPIO_HAL_DataDirection(inputPin -> PortName, inputPin -> PinName, GpioDigitalInput);
    /* Configure pin data direction as input */
    PORT_HAL_SetPullMode(inputPin -> PortName, inputPin -> PinName, inputPin -> Config.PullSelect);
    /* Configure passive filter as input pin */
    PORT_HAL_PassiveFilter(inputPin -> PortName, inputPin -> PinName, inputPin -> Config.PassiveFilterEnable);
    /* Configure interrupts based on configuration */
    PORT_HAL_SetInterruptsMode(inputPin -> PortName, inputPin -> PinName, inputPin -> Config.Interrupt_Config, inputPin -> Priority);

}

void GPIO_DRV_OutputPinInit(Gpio_Output_Pin_Config * outputPin)
{
    /* Enable clock for the corresponding GPIO port */
    SIM_EnablePortClock(outputPin -> PortName);
    /* Set pin mux mode to GPIO */
    PORT_HAL_SetMuxMode(outputPin -> PortName, outputPin -> PinName, PortMuxGpio);
    /* Configure pin data direction as output */
    GPIO_HAL_DataDirection(outputPin -> PortName, outputPin -> PinName, GpioDigitalOutput);
    /* Configure pin data direction as output */
    PORT_HAL_SetSlewRateMode(outputPin -> PortName, outputPin -> PinName, outputPin -> Config.Slew_Rate);
    /* Set drive strength mode based on configuration */
    PORT_HAL_SetDriveStrengthMode(outputPin -> PortName, outputPin -> PinName, outputPin -> Config.DriveStregth);
    /* Set initial logic level based on configuration */
    GPIO_HAL_Output(outputPin -> PortName, outputPin -> PinName, outputPin -> Config.OutputLogic);
}

void GPIO_DRV_TogglePinOutput(Gpio_Output_Pin_Config * outputPin)
{
    /* Toggle the logic level of the specified output pin */
    GPIO_HAL_Toggle_Output(outputPin -> PortName, outputPin -> PinName);
}

void GPIO_DRV_ClearOutput(Gpio_Output_Pin_Config * outputPin)
{
    /* Clear the output (set to low) of the specified output pin */
    GPIO_HAL_Clear_Output(outputPin -> PortName, outputPin -> PinName);

}

uint32_t GPIO_DRV_ReadPinInput(Gpio_Input_Pin_Config * inputPin)
{
   /* Read the logic level of the specified input pin */
   return GPIO_HAL_Set_Input(inputPin -> PortName, inputPin -> PinName);

}

uint32_t GPIO_DRV_InterruptFlag(Gpio_Input_Pin_Config * inputPin)
{
    uint32_t Flag = 0;

    /* Read the status flag */
    Flag = PORT_HAL_InterruptStatusFlag(inputPin -> PortName, inputPin -> PinName);

    /* Clear the flag */
    PORT_HAL_ClearInterrupts(inputPin -> PortName, inputPin -> PinName);

    return Flag;
}

bool GPIO_DRV_SetIntPending(Gpio_Input_Pin_Config * inputPin)
{
	return PORT_HAL_SetIntPending(inputPin -> PortName);
}

void GPIO_DRV_ClearIntPending(Gpio_Input_Pin_Config * inputPin)
{
	PORT_HAL_ClearIntPending(inputPin -> PortName);
}

/* End of file */
