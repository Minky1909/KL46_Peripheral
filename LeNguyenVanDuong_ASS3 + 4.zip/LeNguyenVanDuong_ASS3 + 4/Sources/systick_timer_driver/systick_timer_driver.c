/*
 * systick_timer_driver.c
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include "systick_timer_driver.h"

/************************************************************************************
 * Function
 ************************************************************************************/
void SYSTICK_DRV_Init(void)
{

    /* Disable clock */
    SysTick -> CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk;
    /* Enable system clock, and enable SysTick counter */
    SysTick -> CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
    /* Load initial value into the SysTick timer */
    SysTick -> VAL = SysTick_VAL_CURRENT_Pos;
    /* Enable SysTick interrupt in NVIC */
    NVIC_EnableIRQ(SysTick_IRQn);

}

Systick_State SYSTICK_DRV_Start(uint32_t value)
{
    Systick_State Status;
    uint8_t index;

    if (value < 0xFFFFFF)
    {
        /* Set initial value and load value for SysTick timer */
        SysTick -> VAL = SysTick_VAL_CURRENT_Pos;
        SysTick -> LOAD = (SystemCoreClock / value) - 1;
        /* Reset all timers in the Timer_Group array */
        for (index = 0; index < MAX; index++)
        {
            Timer_Group[index].count = 0;
            Timer_Group[index].user_func = 0;
        }
        Status = SYSTICK_OK;
    }
    else
    {
        Status = SYSTICK_ERROR;
    }
    /* Initialize all timer objects in the list */
    return Status;
}

Systick_State SYSTICK_DRV_AddTimer(Systick_Timer * object)
{
    Systick_State Status;
    uint8_t index;

    for (index = 0; index < MAX; index++)
    {
        /* Find an empty slot in the array */
        if (Timer_Group[index].count == 0)
        {
            Timer_Group[index].user_func = object -> user_func;;
            Timer_Group[index].count = object -> count;
            Status = SYSTICK_OK;
            break;
        }
        else
        {
            Status = SYSTICK_ERROR;
        }

    }
    return Status;
}

uint32_t SYSTICK_DRV_State(void)
{
    uint32_t flag;
    /* Read the COUNTFLAG bit from the CTRL register */
    flag = SysTick -> CTRL & SysTick_CTRL_COUNTFLAG_Msk;
    flag = flag >> SysTick_CTRL_COUNTFLAG_Pos;
    /* Return the count flag */
    return flag;
}

Systick_State SYSTICK_DRV_RemoveTimer(uint8_t index)
{
    Systick_State Status;
    if (Timer_Group[index].count != 0)
    {
        /* Reset the count to 0 and clear the callback function pointer */
        Timer_Group[index].count = 0;
        Timer_Group[index].user_func = 0;
        Status = SYSTICK_OK;
    }
    else
    {
        Status = SYSTICK_ERROR;
    }

    return Status;
}

/* End of file */
