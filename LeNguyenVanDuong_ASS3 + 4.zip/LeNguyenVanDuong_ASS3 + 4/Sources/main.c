/*
 * main.c
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */
/************************************************************************************
 * Include file
 ************************************************************************************/
#include  "gpio_driver.h"
#include "systick_timer_driver.h"

/************************************************************************************
 * Definitions
 ************************************************************************************/
#define GREEN_LED_PORT	(GPIO_D) /* Green LED at PORT D */
#define GREEN_LED_PIN	(5) 	 /* Green LED at Pin 5 */
#define RED_LED_PORT	(GPIO_E) /* Red LED at PORT E */
#define RED_LED_PIN		(29) 	 /* Red LED at Pin 29 */

/************************************************************************************
 * Static Variable
 ************************************************************************************/
static Gpio_Input_Pin_Config inputpin[5]; 	/* Array of configurations for input pins */
static Gpio_Output_Pin_Config Outputpin[5];	/* Array of configurations for output pins */

static Systick_Timer SystickGroup[MAX];		/* Array to store instances of Systick_Timer */

/************************************************************************************
 * Prototypes
 ************************************************************************************/
/*************************************************************************************
  * Function Name:      Input_Config
  * Description:        Configures input pins.
  ************************************************************************************/
static void Input_Config(void);

/*************************************************************************************
  * Function Name:      Output_Config
  * Description:		Configures output pins
  ************************************************************************************/
static void Output_Config(void);

/*************************************************************************************
  * Function Name:      Toggle_GreenLED
  * Description:		Toggle green LED
  ************************************************************************************/
static void Toggle_GreenLED(void);

/*************************************************************************************
  * Function Name:      Toggle_RedLED
  * Description:		Toggle red LED
  ************************************************************************************/
static void Toggle_RedLED(void);

/************************************************************************************
 * Function
 ************************************************************************************/
static void Input_Config(void)
{

    inputpin[0].PinName = GPIO_PINS_OUT_OF_RANGE;
}

static void Output_Config(void)
{
    Outputpin[0].PortName = RED_LED_PORT;
    Outputpin[0].PinName = RED_LED_PIN;
    Outputpin[0].Config.Slew_Rate = PortFastSlew;
    Outputpin[0].Config.DriveStregth = PortHighDriveStrength;
    Outputpin[0].Config.OutputLogic = GpioDigitalHigh;

    Outputpin[1].PortName = GREEN_LED_PORT;
    Outputpin[1].PinName = GREEN_LED_PIN;
    Outputpin[1].Config.Slew_Rate = PortFastSlew;
    Outputpin[1].Config.DriveStregth = PortHighDriveStrength;
    Outputpin[1].Config.OutputLogic = GpioDigitalHigh;

    Outputpin[2].PinName = GPIO_PINS_OUT_OF_RANGE;

}

static void Toggle_GreenLED(void)
{

    GPIO_DRV_TogglePinOutput( & Outputpin[1]);
}

static void Toggle_RedLED(void)
{
    GPIO_DRV_TogglePinOutput( & Outputpin[0]);
}

void SysTick_Handler(void)
{
    uint8_t index;

    for (index = 0; index < MAX; index++)
    {
    	/* Check if the user_func exists and the timer count is greater than 0 */
        if (Timer_Group[index].user_func != 0 && Timer_Group[index].count > 0)
        {
        	/* Decrement the timer count */
            Timer_Group[index].count--;
            /* If the timer count reaches 0, execute the callback function and remove the timer */
            if (Timer_Group[index].count == 0)
            {
                Timer_Group[index].user_func();
                SYSTICK_DRV_RemoveTimer(index);
            }
        }
    }
}

/*************************************************************************************
  * Function Name:          main
  * Description:            Main function
  ************************************************************************************/
int main(void)
{
    Input_Config();
    Output_Config();
    GPIO_DRV_Init(inputpin, Outputpin);

    SYSTICK_DRV_Init();
    SYSTICK_DRV_Start(1000);

    SystickGroup[0].count = 2000;
    SystickGroup[0].user_func = & Toggle_GreenLED;

    SystickGroup[1].count = 1000;
    SystickGroup[1].user_func = & Toggle_RedLED;

    /*  Main program loop */
    while (1)
    {
    	/* If SysTick timer state is 0, add timers to the Timer_Group array */
        if (0 == SYSTICK_DRV_State())
        {
            SYSTICK_DRV_AddTimer( & SystickGroup[0]);
            SYSTICK_DRV_AddTimer( & SystickGroup[1]);
        }

    }
    return 0;
}

/* End of file */
