/*
 * port_hal.h
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */

#ifndef _PORT_HAL_H_
#define _PORT_HAL_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "sim_hal.h"
#include <stdbool.h>

/* Type-define enum for port pin multiplexing options */
typedef enum
{

    PortPinDisable 		= 0U,	/* Disable the pin multiplexing */
	PortMuxGpio         = 1U,	/* Configure the pin for general-purpose I/O */
	PortMuxAlt2			= 2U,	/* Configure the pin for alternate 2 */
	PortMuxAlt3			= 3U,	/* Configure the pin for alternate 3 */
	PortMuxAlt4			= 4U,	/* Configure the pin for alternate 4 */
	PortMuxAlt5			= 5U,	/* Configure the pin for alternate 5 */
	PortMuxAlt6			= 6U,	/* Configure the pin for alternate 6 */
	PortMuxAlt7			= 7U,	/* Configure the pin for alternate 7 */
}Port_Mux;

/* Type-define enum for port pull-up/pull-down options */
typedef enum
{
	PortPullDown 		= 0U,	/* Configure the pin with pull-down resistor */
	PortPullUp   		= 1U,	/* Configure the pin with pull-up resistor */

}Port_Pull;

/* Type-define enum for port slew rate options */
typedef enum
{
	PortFastSlew		= 0U,	/* Configure the pin with fast slew rate */
	PortSlowSlew		= 1U,	/* Configure the pin with slow slew rate */

}Port_Slew_Rate;

/* Type-define enum for port drive strength options */
typedef enum
{
	PortLowDriveStregth   = 0U,	/* Configure the pin with low drive strength */
	PortHighDriveStrength = 1U 	/* Configure the pin with high drive strength */

}Port_Drive_Strength;

/* Type-define enum for port passive filter options */
typedef enum
{
	DisablePassiveFilter  = 0U,	/* Disable the passive filter on the pin */
	EnablePassiveFilter	  = 1U,	/* Enable the passive filter on the pin */

}Port_Passive_Filter;

/* Type-define enum for port interrupt configuration options */
typedef enum
{

	PortIntDisabled    = 0x0U,	/* Type-define enum for port interrupt configuration options */
	PortDmaRisingEdge  = 0x1U,  /* DMA request on rising edge */
	PortDmaFallingEdge = 0x2U,  /* DMA request on falling edge */
	PortDmaEitherEdge  = 0x3U,  /* Enable DMA request on either edge */
	PortIntLogicZero   = 0x8U,  /* Interrupt when logic zero */
	PortIntRisingEdge  = 0x9U,  /* Interrupt on rising edge  */
	PortIntFallingEdge = 0xAU,  /* Interrupt on falling edge */
	PortIntEitherEdge  = 0xBU,  /* Interrupt on either edge */
	PortIntLogicOne    = 0xCU	/* Interrupt when logic one */

}Port_Interrupt_Config;

/* Type-define enum for HAL port names */
typedef enum
{
     HAL_PORTA        = 1U,		/* HAL port identifier for PORTA */
     HAL_PORTB        = 2U,		/* HAL port identifier for PORTB */
     HAL_PORTC        = 3U,		/* HAL port identifier for PORTC */
     HAL_PORTD        = 4U,		/* HAL port identifier for PORTD */
     HAL_PORTE        = 5U,		/* HAL port identifier for PORTE */
} Hal_Port;

/* Type-define enum for port state */
typedef enum
{
	HAL_PORT_ERROR   = 0U,		/* HAL port operation resulted in an error */
	HAL_PORT_OK      = 1U,		/* HAL port operation was successful */

}Port_State;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:		PORT_HAL_SetMuxMode
  * Description:		Set the pin muxing mode for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @param Muxing:      Muxing mode to be set for the specified pin
  * @return None
  ************************************************************************************/
void PORT_HAL_SetMuxMode(Hal_Port Port , uint8_t Pin, Port_Mux Muxing);

/*************************************************************************************
  * Function Name:		PORT_HAL_SetPullMode
  * Description:		Configures the pull-up or pull-down mode for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @param Config: 		Pull configuration to be set for the specified pin
  * @return None
  ************************************************************************************/
void PORT_HAL_SetPullMode(Hal_Port Port , uint8_t Pin, Port_Pull Config);

/*************************************************************************************
  * Function Name:		PORT_HAL_SetInterruptsMode
  * Description:		Configures the interrupt mode for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @param Config: 		Interrupt configuration to be set for the specified pin
  * @return Status:		Status of the operation
  ************************************************************************************/
Port_State PORT_HAL_SetInterruptsMode(Hal_Port Port , uint8_t Pin, Port_Interrupt_Config Config, uint8_t Priority);

/*************************************************************************************
  * Function Name:		PORT_HAL_InterruptStatusFlag
  * Description:		Retrieves the interrupt status flag for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @return uint32_t: 	Interrupt status flag
  ************************************************************************************/
uint32_t PORT_HAL_InterruptStatusFlag(Hal_Port Port, uint8_t Pin);

/*************************************************************************************
  * Function Name:		PORT_HAL_ClearInterrupts
  * Description:		Clears the interrupt status flag for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @return None
  ************************************************************************************/
void PORT_HAL_ClearInterrupts(Hal_Port Port,uint8_t Pin);

/*************************************************************************************
  * Function Name:		PORT_HAL_SetSlewRateMode
  * Description:		Configures the slew rate mode for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @param Config: 		Slew rate configuration to be set for the specified pin
  * @return None
  ************************************************************************************/
void PORT_HAL_SetSlewRateMode(Hal_Port Port ,uint8_t Pin, Port_Slew_Rate Config);

/*************************************************************************************
  * Function Name:		PORT_HAL_SetDriveStrengthMode
  * Description:		Configures the drive strength mode for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @param Config: 		Slew rate configuration to be set for the specified pin
  * @return None
  ************************************************************************************/
void PORT_HAL_SetDriveStrengthMode(Hal_Port Port ,uint8_t Pin,Port_Drive_Strength Config);

/*************************************************************************************
  * Function Name:		PORT_HAL_PassiveFilter
  * Description:		Configures the passive filter mode for a specific port and pin
  * @param Port: 		Identifier for the HAL_PORT
  * @param Pin: 		Pin number within the port
  * @param Config: 		Passive filter configuration to be set for the specified pin
  * @return None
  ************************************************************************************/
void PORT_HAL_PassiveFilter(Hal_Port Port ,uint8_t Pin, Port_Passive_Filter Config);

/*************************************************************************************
  * Function Name:		PORT_HAL_SetIntPending
  * Description:		Read the individual pin-interrupt status flag
  * @param Port: 		Identifier for the HAL_PORT
  * @return bool		True if successful, false if the port is not recognized
  ************************************************************************************/
bool PORT_HAL_SetIntPending(Hal_Port Port);

/*************************************************************************************
  * Function Name:		PORT_HAL_ClearIntPending
  * Description:		Clears the individual pin-interrupt status flag
  * @param Port: 		Identifier for the HAL_PORT
  * @return None
  ************************************************************************************/
void PORT_HAL_ClearIntPending(Hal_Port Port);

#endif /* SOURCES_GPIO_HAL_PORT_HAL_H_ */
