/*
 * gpio_driver.h
 *
 *  Created on: Dec 9, 2023
 *      Author: Le Nguyen Van Duong
 */

#ifndef _GPIO_DRIVER_H_
#define _GPIO_DRIVER_H_

/************************************************************************************
 * Include file
 ************************************************************************************/
#include "sim_hal.h"
#include "port_hal.h"
#include "gpio_hal.h"
#include <stdbool.h>

/* Indicates the end of a pin configuration structure */
#define GPIO_PINS_OUT_OF_RANGE (0xFFFFFFFFU)

/* Type-define enum for GPIO ports */
typedef enum
{
   GPIO_A       = 1U,
   GPIO_B       = 2U,
   GPIO_C       = 3U,
   GPIO_D       = 4U,
   GPIO_E       = 5U,
}gpio_name;

/* Structure for configuring GPIO input pins */
typedef struct
{
	bool 				  PullEnable;			/* Enable or disable pull resistor */
	Port_Pull 			  PullSelect;			/* Select pull configuration */
	Port_Passive_Filter   PassiveFilterEnable;	/* Enable or disable passive filter */
	Port_Interrupt_Config Interrupt_Config;		/* Configuration for interrupt handling */

}Gpio_Input_Pin;

/* Structure for configuring GPIO output pins */
typedef struct
{
	Pin_Logic 			  OutputLogic;			/* Logic level for initial output */
	Port_Slew_Rate 		  Slew_Rate;			/* Slew rate configuration for the pin */
	Port_Drive_Strength   DriveStregth;			/* Drive strength configuration for the pin */

}Gpio_Output_Pin;

/* Configuration structure for GPIO input pins */
typedef struct
{
	gpio_name 			  PortName;				/* GPIO port name */
	uint32_t 		      PinName;				/* GPIO pin number */
	Gpio_Input_Pin 		  Config;				/* Configuration for the input pin */

}Gpio_Input_Pin_Config;

/* Configuration structure for GPIO input pins */
typedef struct
{
	gpio_name 			  PortName;				/* GPIO port name */
	uint32_t 			  PinName;				/* GPIO pin number */
	Gpio_Output_Pin 	  Config;				/* Configuration for the output pin */

}Gpio_Output_Pin_Config;

/************************************************************************************
 * Prototypes
 ************************************************************************************/

/*************************************************************************************
  * Function Name:		GPIO_DRV_Init
  * Description:		Initializes GPIO input and output pins based on the provided configurations.
  * @param InputPins: 	Configuration array for input pins.
  * @param OutputPins:  Configuration array for output pins.
  * @return None
  ************************************************************************************/
void GPIO_DRV_Init( Gpio_Input_Pin_Config * InputPins,Gpio_Output_Pin_Config * OutputPins);

/*************************************************************************************
  * Function Name:		GPIO_DRV_InputPinInit
  * Description:		Initializes a GPIO input pin based on the provided configuration.
  * @param InputPins: 	Configuration for the input pin.
  * @return None
  ************************************************************************************/
void GPIO_DRV_InputPinInit(Gpio_Input_Pin_Config * InputPin);

/*************************************************************************************
  * Function Name:		GPIO_DRV_OutputPinInit
  * Description:		Initializes a GPIO output pin based on the provided configuration.
  * @param outputPin: 	Configuration for the output pin.
  * @return None
  ************************************************************************************/
void GPIO_DRV_OutputPinInit( Gpio_Output_Pin_Config * OutputPin);

/*************************************************************************************
  * Function Name:		GPIO_DRV_TogglePinOutput
  * Description:		Toggles the logic level of a GPIO output pin.
  * @param outputPin: 	Configuration for the output pin.
  * @return None
  ************************************************************************************/
void GPIO_DRV_TogglePinOutput(Gpio_Output_Pin_Config * outputPin);

/*************************************************************************************
  * Function Name:		GPIO_DRV_ReadPinInput
  * Description:		Reads the logic level of a GPIO input pin.
  * @param inputPin: 	Configuration for the input pin.
  * @return uint32_t:   Logic level of the input pin (0 or 1).
  ************************************************************************************/
uint32_t GPIO_DRV_ReadPinInput(Gpio_Input_Pin_Config  *  inputPin);

/*************************************************************************************
  * Function Name:		GPIO_DRV_ClearOutput
  * Description:		Clears (sets to low) the output of a GPIO output pin.
  * @param outputPin: 	Configuration for the output pin.
  * @return None
  ************************************************************************************/
void GPIO_DRV_ClearOutput(Gpio_Output_Pin_Config * outputPin);

/*************************************************************************************
  * Function Name:		GPIO_DRV_InterruptFlag
  * Description:		Reads and clears the interrupt flag of a GPIO input pin.
  * @param inputPin: 	Configuration for the input pin.
  * @return uint32_t: 	Interrupt status flag.
  ************************************************************************************/
uint32_t GPIO_DRV_InterruptFlag(Gpio_Input_Pin_Config  *  inputPin);

#endif /* SOURCES_GPIO_DRIVER_H_ */
